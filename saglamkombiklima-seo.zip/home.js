

    // 1. GEMINI AI USTA MOTORU
    let lastDiagnosedIssue = "";

    function renderDiagnostic(data) {
      const box=document.getElementById('aiResultBox'),response=document.getElementById('aiResponseText');
      stAiContact(data.emergency_phone);
      response.innerHTML=stEscape(data.text||'Marka/model ve arıza belirtisini biraz daha tarif eder misiniz?').replace(/\n/g,'<br>');
      const source=document.getElementById('aiSource');
      if(source)source.textContent=data.source==='ai'?'AI teknik ön değerlendirme':data.source==='emergency'?'Öncelikli güvenlik bilgisi':'Belirti rehberi';
      box.classList.remove('hidden');
    }

    function showFallbackDiagnostic(device, issue) {
      const data=window.STDiagnosticGuide?window.STDiagnosticGuide(device,issue):{source:'guide',text:'Marka/modeli, hata kodunu ve sorunun ne zaman oluştuğunu paylaşın. İç parçalara müdahale etmeden Sağlam Teknik ile servis kontrolü planlayabilirsiniz: 0534 622 5515.'};
      renderDiagnostic(data);return data;
    }

    async function diagnoseIssue() {
      const device=document.getElementById('deviceSelect').value,issue=document.getElementById('issueInput').value.trim();
      if(issue.length<3){alert('Lütfen arıza belirtisini veya hata kodunu en az 3 karakterle yazın.');return;}
      if(issue.length>1200){alert('Arıza açıklamasını biraz kısaltın; en fazla 1200 karakter kullanabilirsiniz.');return;}
      const button=document.getElementById('askBtn');if(button.disabled)return;
      lastDiagnosedIssue=`${device}: ${issue}`;
      const initial=showFallbackDiagnostic(device,issue);
      // Güvenlik yönlendirmesi ve belirti rehberi bağlantıyı beklemeden görünür.
      if(initial.source==='emergency')return;
      button.disabled=true;document.getElementById('aiLoading').classList.remove('hidden');
      const source=document.getElementById('aiSource');if(source)source.textContent='Belirti rehberi · AI değerlendirmesi bekleniyor…';
      try {
        const data=await stApi('ai',{device,issue});
        if(data.text)renderDiagnostic(data);else showFallbackDiagnostic(device,issue);
      }catch(error){showFallbackDiagnostic(device,issue);}
      finally{button.disabled=false;button.classList.remove('hidden');document.getElementById('aiLoading').classList.add('hidden');}
    }

    function sendToWhatsappFromAI() {
      const issue = lastDiagnosedIssue || "Kombi / Klima arızası";
      const message = `Merhaba Sağlam Teknik, web sitenizdeki AI Usta üzerinden arıza tespiti yaptım.%0A%0A*Arıza Detayım:* ${encodeURIComponent(issue)}%0A%0AEvime nöbetçi usta yönlendirilmesini rica ediyorum.`;
      window.open(`https://wa.me/905346225515?text=${message}`, '_blank');
    }

    function selectDeviceAndFocus(device) {
      const select = document.getElementById('deviceSelect');
      select.value = device;
      document.getElementById('issueInput').focus();
      document.getElementById('hero').scrollIntoView({ behavior: 'smooth' });
    }

    // 2. ARIZA KAYDI BIRAK
    function toggleServiceTicketModal(show) {
      const modal = document.getElementById('serviceTicketModal');
      if (show) {
        document.getElementById('ticketSubmitBtn').classList.remove('hidden');
        document.getElementById('ticketSuccessMsg').classList.add('hidden');
        stError('ticketError','');
        const currentIssue = document.getElementById('issueInput').value.trim();
        const currentDevice = document.getElementById('deviceSelect').value;
        if (currentIssue) {
          document.getElementById('ticketIssue').value = currentIssue;
        }
        if (currentDevice) {
          document.getElementById('ticketDevice').value = currentDevice;
        }
        modal.classList.remove('hidden');
      } else {
        modal.classList.add('hidden');
      }
    }

    async function submitServiceTicket(e) {
      if (e) e.preventDefault();

      const name = document.getElementById('ticketName')?.value?.trim() || '';
      const phone = document.getElementById('ticketPhone')?.value?.trim() || '';
      const district = document.getElementById('ticketDistrict')?.value?.trim() || '';
      const device = document.getElementById('ticketDevice')?.value || 'Kombi';
      const issue = document.getElementById('ticketIssue')?.value?.trim() || '';

      if (!name || !phone || !district || !issue) {
        alert("Lütfen tüm alanları doldurunuz.");
        return false;
      }

      const submitBtn = document.getElementById('ticketSubmitBtn');
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> İletiliyor...';
      }

      const waMessage = `*YENİ ARIZA KAYDI*%0A%0A*Müşteri:* ${encodeURIComponent(name)}%0A*Telefon:* ${encodeURIComponent(phone)}%0A*İlçe:* ${encodeURIComponent(district)}%0A*Cihaz:* ${encodeURIComponent(device)}%0A*Arıza:* ${encodeURIComponent(issue)}`;
      const waBtn = document.getElementById('ticketDirectWhatsappBtn');
      if (waBtn) {
        waBtn.href = `https://wa.me/905346225515?text=${waMessage}`;
      }

      const form = document.getElementById('serviceTicketForm');
      const payload = {name,phone,district,device,issue,website:document.getElementById('ticketWebsite').value};
      stError('ticketError','');document.getElementById('ticketSuccessMsg').classList.add('hidden');
      try {
        await stApi('ticket',payload,stRequestKey(form,payload));
        document.getElementById('ticketSuccessMsg').classList.remove('hidden');
        submitBtn.classList.add('hidden');
        delete form.dataset.requestKey; delete form.dataset.requestBody;
      } catch (err) {
        stError('ticketError',err.name==='AbortError'?'Bağlantı zaman aşımına uğradı. Aynı talebi tekrar gönderebilirsiniz.':err.message);
      } finally { submitBtn.disabled=false; submitBtn.innerHTML='<i class="fa-solid fa-paper-plane"></i> Arıza Kaydını Hemen Gönder'; }
      return false;
    }

    function handleServiceCardClick(category) {
      filterByCat(category);
      const deviceMap = { kombi: 'Kombi', klima: 'Klima', petek: 'Petek' };
      selectDeviceAndFocus(deviceMap[category] || 'Kombi');
    }

    // 3. DOĞRULANMIŞ YORUMLAR VERİTABANI
    const allFileReviews = [
      { author: "Soner U.", date: "07 Nis 2026", service: "Kombi Tamiri", cat: "kombi", rating: 5, comment: "Bilgi ve tecrübesiyle hızlı çözüme ulaştım teşekkürler." },
      { author: "Muharrem T.", date: "07 Nis 2026", service: "Kombi Tamiri", cat: "kombi", rating: 5, comment: "Zamanında geldi, sorunu hemen tespit edip çözdü. İşinin ehli bir usta." },
      { author: "Sezgin E.", date: "08 Tem 2025", service: "Kombi Su Akıtıyor", cat: "kombi", rating: 5, comment: "Kombi su akıtıyordu, basınç kontrolü yapılarak sorun giderildi. Eline sağlık." },
      { author: "Mehmet Ali Ö.", date: "31 Mar 2023", service: "Klima Soğutmuyor", cat: "klima", rating: 5, comment: "Klima soğutmuyordu, kaçak testi ve gaz dolumu yapıldı. Çok memnun kaldım." },
      { author: "Hüsnü S.", date: "01 Eki 2022", service: "Kombi Su Akıtıyor", cat: "kombi", rating: 5, comment: "Çok teşekkür ederiz." },
      { author: "Baris C.", date: "16 Tem 2022", service: "Kombi Su Akıtıyor", cat: "kombi", rating: 5, comment: "İyi işçilik." },
      { author: "Alper A.", date: "06 Kas 2021", service: "Kombi Bakım", cat: "kombi", rating: 5, comment: "Yıllık bakım ve temizlik yapıldı. Çok dürüst ve temiz çalışan bir usta." },
      { author: "Egemen C.", date: "21 Kas 2020", service: "Kombi Tamiri", cat: "kombi", rating: 5, comment: "Sorunu hemen çözdü, güvenilir esnaf." },
      { author: "m ****", date: "10 Kas 2020", service: "Kombi Tamiri", cat: "kombi", rating: 5, comment: "Mustafa arkadaşa çok teşekkür ederim tavsiye ederim." },
      { author: "Sefa A.", date: "09 Kas 2020", service: "Kombi Tamiri", cat: "kombi", rating: 5, comment: "2 saat önce teklif verdi geldi hemen destek aldım, sorunu çözdü ustam. eline emeğine sağlık." },
      { author: "Oğuz S.", date: "19 Oca 2018", service: "Kombi Tamiri", cat: "kombi", rating: 5, comment: "Teşekkürler eline sağlık." },
      { author: "Talha A.", date: "06 Oca 2018", service: "Kombi Tamiri", cat: "kombi", rating: 4, comment: "" },
      { author: "e ****", date: "30 Ara 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "" },
      { author: "Ersin S.", date: "27 Ara 2017", service: "Kombi Su Akıtıyor", cat: "kombi", rating: 5, comment: "Bilgi vererek ve açıklayarak işi çözdü sağolsun.eline sağlık usta." },
      { author: "s ****", date: "27 Ara 2017", service: "Kombi Tamiri", cat: "kombi", rating: 5, comment: "Güvenilir ve harika işçilik.." },
      { author: "a ****", date: "27 Ara 2017", service: "Kombi Tamiri", cat: "kombi", rating: 5, comment: "Eline koluna sağlık usta..." },
      { author: "Fevzi E.", date: "23 Ara 2017", service: "Kombi Tamiri", cat: "kombi", rating: 5, comment: "Hızlı ve temiz iş. Kombinin yanmış 2 parçası değişti. Uygun fiyatlıydı." },
      { author: "Fadime A.", date: "23 Ara 2017", service: "Kombi Tamiri", cat: "kombi", rating: 5, comment: "Teşekkür ederiz gayet ilgiliydi ve sorunumuzu çözdü." },
      { author: "Enes T.", date: "23 Ara 2017", service: "Kombi Tamiri", cat: "kombi", rating: 5, comment: "İlgili ve hızlıydı." },
      { author: "Ayla E.", date: "19 Ara 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Zamanında geldi ve işini ustalıkla yaptı." },
      { author: "Belgin B.", date: "10 Ara 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Aldığımız hizmetten son derece memnun kaldık." },
      { author: "Adnan Ş.", date: "10 Ara 2017", service: "Kombi Servisi", cat: "kombi", rating: 4, comment: "Ustalık iyi, işimizi gördü." },
      { author: "Ozan Ç.", date: "29 Kas 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Daha önce de çağırmıştım motor dediler, Mustafa Bey kısa sürede hesaplı çözdü." },
      { author: "Oğuzhan Ö.", date: "17 Kas 2017", service: "Kombi Bakım", cat: "kombi", rating: 5, comment: "Profesyonel ve düzgün hizmet." },
      { author: "Kemal A.", date: "15 Kas 2017", service: "Kombi Servisi", cat: "kombi", rating: 4, comment: "Servis hızlıydı." },
      { author: "Kadir Eren S.", date: "10 Kas 2017", service: "Kombi Bakım", cat: "kombi", rating: 5, comment: "Kombi bakımı ve peteklerin temizliği yapıldı. Sorunsuz çalışıyor." },
      { author: "Muhammed A.", date: "10 Kas 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Kiracımın kombisi bozulmuştu, Mustafa bey gitti çok memnun kalmışlar." },
      { author: "Mert can E.", date: "07 Kas 2017", service: "Kombi Tamiri", cat: "kombi", rating: 5, comment: "Çok temiz iş yaptı kesinlikle tavsiye ediyorum." },
      { author: "Meray A.", date: "06 Kas 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Çok temiz bir iş çıkardı. Aynı gün parça değişimi yaptı." },
      { author: "İbrahim T.", date: "04 Kas 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Basınçlı temizlik ve bakım yaptırdım. İşinin ehli bir arkadaş." },
      { author: "Serkan B.", date: "01 Kas 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Pratik ve temiz çalışan biri. Çok memnun kaldım." },
      { author: "Ahmet Ö.", date: "30 Eki 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Kısa sürede yaptı tavsiye ederim." },
      { author: "Mert S.", date: "06 Eki 2017", service: "Kombi Bakım", cat: "kombi", rating: 5, comment: "Vaktinde gelen ve işinde başarılı usta." },
      { author: "Murat T.", date: "03 Eki 2017", service: "Kombi Tamiri", cat: "kombi", rating: 5, comment: "Pazar günü beni kurtararak süper servis sağladı." },
      { author: "Bülent K.", date: "09 Eyl 2017", service: "Makineli Petek Yıkama", cat: "petek", rating: 5, comment: "Hızlı ve dürüst usta. Kombi ve petek tavsiyeleri için teşekkürler." },
      { author: "Ilker B.", date: "07 Eyl 2017", service: "Klima Bakımı", cat: "klima", rating: 5, comment: "Uygun fiyata hızlı ve temiz iş oldu teşekkürler." },
      { author: "Seher T.", date: "05 Eyl 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Aynı gün içinde kombi arızası giderildi. Teşekkürler." },
      { author: "Fatih M.", date: "03 Eyl 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Yetkili servisin bozuk dediği kartı kurtardı problemi çözdü." },
      { author: "Murat A.", date: "28 Ağu 2017", service: "Klima Servisi", cat: "klima", rating: 5, comment: "İşinin hakkını veren birisi, gayet memnun kaldım." },
      { author: "**** ****", date: "24 Ağu 2017", service: "Klima Servisi", cat: "klima", rating: 5, comment: "Beklediğimden iyi hizmet, temiz çalıştı." },
      { author: "Benim A.", date: "11 Ağu 2017", service: "Klima Servisi", cat: "klima", rating: 5, comment: "Gaz dolumu süper hizmet sağol ustam." },
      { author: "Sabri Ö.", date: "07 Ağu 2017", service: "Makineli Petek Yıkama", cat: "petek", rating: 5, comment: "Sıkıntısız bir şekilde petek temizliği ve kombi bakımını yaptı." },
      { author: "Hasan A.", date: "05 Ağu 2017", service: "Klima Servisi", cat: "klima", rating: 5, comment: "Hızlı ve dürüst esnaf." },
      { author: "Mesut D.", date: "27 Tem 2017", service: "Klima Tamiri", cat: "klima", rating: 5, comment: "Söz verdiği saatte geldi, klima ilk günkü gibi soğutuyor." },
      { author: "Fatih A.", date: "26 Tem 2017", service: "Klima Bakımı", cat: "klima", rating: 5, comment: "Açık konuşan, güven veren usta." },
      { author: "Özgür Ş.", date: "26 Tem 2017", service: "Klima Gaz Dolumu", cat: "klima", rating: 4, comment: "İşimizi güzelce halletti." },
      { author: "Lvent Ş.", date: "19 Tem 2017", service: "Klima Tamiri", cat: "klima", rating: 5, comment: "Söz verdiği zamanda geldi, anlaştığımız fiyatta kaldı." },
      { author: "Abdullah A.", date: "17 Tem 2017", service: "Klima Tamiri", cat: "klima", rating: 5, comment: "Telefonda yapmam gerekeni anlatıp halletti, Allah razı olsun." },
      { author: "Metin T.", date: "09 Tem 2017", service: "Klima Tamiri", cat: "klima", rating: 5, comment: "Kaliteli servis herkese tavsiye ederim." },
      { author: "Alparslan Ç.", date: "06 Tem 2017", service: "Klima Servisi", cat: "klima", rating: 5, comment: "10 numara 5 yıldız dürüst bir arkadaş." },
      { author: "Cenk S.", date: "05 Tem 2017", service: "Klima Bakım", cat: "klima", rating: 5, comment: "İşinin ehli, uygun ücretle yaptı." },
      { author: "Dicle Can A.", date: "05 Tem 2017", service: "Klima Servisi", cat: "klima", rating: 5, comment: "Hızlı servis aldık teşekkürler." },
      { author: "Ersin C.", date: "03 Tem 2017", service: "Klima Servisi", cat: "klima", rating: 5, comment: "Sıcaktan kurtulduk eline sağlık." },
      { author: "**** ****", date: "02 Tem 2017", service: "Klima Servisi", cat: "klima", rating: 5, comment: "10 dakika içinde gelerek problemi halletti." },
      { author: "Nurdan T.", date: "04 Haz 2017", service: "Makineli Petek Yıkama", cat: "petek", rating: 5, comment: "Sözüne sadık, titiz çalışan bir usta." },
      { author: "Lutfi F.", date: "22 Nis 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Jet hızıyla gelip sorunu çözdü. Teşekkürler." },
      { author: "Pelin G.", date: "26 Mar 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Gönül rahatlığıyla tavsiye ederim." },
      { author: "İpek A.", date: "11 Şub 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Saygılı beyefendi, işini hakkıyla yaptı." },
      { author: "Serap T.", date: "24 Oca 2017", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Allah razı olsun Mustafa Bey sorunumuzu hemen çözdün." },
      { author: "Şenay Ç.", date: "23 Eyl 2016", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "İlk defa bir servis tam vaktinde kapımdaydı." },
      { author: "Ahmet K.", date: "08 Ağu 2016", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Çok uygun fiyata yaptı, eline sağlık ustam." },
      { author: "Uğur Ş.", date: "22 Haz 2016", service: "Kombi Servisi", cat: "kombi", rating: 5, comment: "Sanki kendi evinin eksiğini yapıyor gibi titiz çalıştı." }
    ];

    let currentFilterCat = 'all';

    function renderReviewsList(list) {
      const container = document.getElementById('reviewsContainer');
      if (!container) return;
      container.innerHTML = '';

      if (!list || list.length === 0) {
        container.innerHTML = `
          <div class="glass-box rounded-2xl p-8 text-center text-slate-400">
            <i class="fa-solid fa-magnifying-glass text-3xl mb-2 text-slate-500"></i>
            <p class="text-xs font-semibold">Aradığınız kriterlere uygun servis yorumu bulunamadı.</p>
          </div>
        `;
        return;
      }

      list.forEach(r => {
        const authorName = stEscape(r.author || r.ad || r.isim || 'Müşteri');
        const reviewText = stEscape(r.comment || r.mesaj || r.yorum || '');
        const ratingVal = Math.max(1,Math.min(5,parseInt(r.rating || r.puan || 5) || 5));
        const reviewDate = stEscape(r.date || r.tarih || 'Güncel');
        const serviceName = stEscape(r.service || r.hizmet || 'Teknik Servis');

        let stars = '';
        for (let i = 0; i < ratingVal; i++) {
          stars += '<i class="fa-solid fa-star text-amber-400"></i>';
        }
        for (let i = ratingVal; i < 5; i++) {
          stars += '<i class="fa-solid fa-star text-slate-600"></i>';
        }

        const initials = authorName.replace(/[^a-zA-ZğüşıöçĞÜŞİÖÇ]/g, '').slice(0, 2).toUpperCase() || 'ST';

        const card = document.createElement('div');
        card.className = "review-item glass-box rounded-2xl p-4 sm:p-5 flex flex-col justify-between";
        card.setAttribute('data-category', r.cat || 'kombi');

        card.innerHTML = `
          <div>
            <div class="flex items-center justify-between pb-2.5 mb-2.5 border-b border-emerald-500/10">
              <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-full bg-emerald-950/80 border border-emerald-400/40 text-emerald-400 font-bold font-mono flex items-center justify-center text-[11px] shrink-0">
                  ${initials}
                </div>
                <div>
                  <h4 class="text-xs font-bold text-white tracking-wide">${authorName}</h4>
                  <span class="text-[10px] text-slate-400 font-medium">${reviewDate} • ${serviceName}</span>
                </div>
              </div>
              <span class="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 text-[10px] font-bold border border-emerald-400/20">
                <i class="fa-solid fa-check text-[9px] mr-0.5"></i> ${r.source === "site" ? "Yönetici onaylı" : "Doğrulandı"}
              </span>
            </div>

            <div class="flex items-center gap-2 mb-2">
              <div class="flex text-xs gap-0.5">${stars}</div>
              <span class="text-[10px] font-mono font-bold text-amber-400">${ratingVal}.0</span>
            </div>

            ${reviewText ? `
              <p class="text-xs text-slate-200 leading-relaxed italic">
                "${reviewText}"
              </p>
            ` : `
              <p class="text-[11px] text-slate-400 italic">
                Müşteri memnuniyetini <strong>${ratingVal} yıldız</strong> vererek onayladı.
              </p>
            `}
          </div>

          <div class="pt-3 mt-3 border-t border-emerald-500/10 text-[10px] font-mono text-emerald-400/80 flex items-center justify-between">
            <span>İstanbul Avrupa Yakası</span>
            <span>1 Yıl İşçilik Garantili</span>
          </div>
        `;

        container.appendChild(card);
      });
    }

    function filterByCat(category, ev) {
      currentFilterCat = category;
      
      const btnAll = document.getElementById('btnCatAll');
      const btnKombi = document.getElementById('btnCatKombi');
      const btnKlima = document.getElementById('btnCatKlima');
      const btnPetek = document.getElementById('btnCatPetek');

      [btnAll, btnKombi, btnKlima, btnPetek].forEach(btn => {
        if (!btn) return;
        btn.className = "cat-filter-btn px-4 py-2 rounded-xl text-xs font-bold bg-[#041c20] text-slate-300 hover:text-white border border-transparent transition-all";
      });

      document.body.classList.remove('theme-kombi', 'theme-klima', 'theme-petek');

      if (category === 'all' && btnAll) {
        btnAll.className = "cat-filter-btn px-4 py-2 rounded-xl text-xs font-bold bg-emerald-400 text-slate-950 shadow-[0_0_15px_rgba(0,229,117,0.4)] transition-all";
      } else if (category === 'kombi' && btnKombi) {
        btnKombi.className = "cat-filter-btn px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-red-600 via-orange-600 to-amber-500 text-white shadow-[0_0_25px_rgba(239,68,68,0.85)] border border-red-400 scale-105 transition-all";
        document.body.classList.add('theme-kombi');
      } else if (category === 'klima' && btnKlima) {
        btnKlima.className = "cat-filter-btn px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-cyan-400 via-sky-500 to-blue-600 text-white shadow-[0_0_25px_rgba(6,182,212,0.85)] border border-cyan-300 scale-105 transition-all";
        document.body.classList.add('theme-klima');
      } else if (category === 'petek' && btnPetek) {
        btnPetek.className = "cat-filter-btn px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-amber-500 via-amber-600 to-orange-500 text-slate-950 shadow-[0_0_25px_rgba(245,158,11,0.85)] border border-amber-300 scale-105 transition-all";
        document.body.classList.add('theme-petek');
      }

      applyAllFilters();
    }

    function filterBySearch() {
      applyAllFilters();
    }

    function applyAllFilters() {
      const input = document.getElementById('reviewSearchInput');
      const q = input ? input.value.toLowerCase().trim() : '';
      let list = allFileReviews;

      if (currentFilterCat !== 'all') {
        list = list.filter(r => r.cat === currentFilterCat);
      }

      if (q) {
        list = list.filter(r => {
          const author = (r.author || r.ad || r.isim || '').toLowerCase();
          const comment = (r.comment || r.mesaj || r.yorum || '').toLowerCase();
          const service = (r.service || r.hizmet || '').toLowerCase();
          return author.includes(q) || comment.includes(q) || service.includes(q);
        });
      }

      renderReviewsList(list);
    }


    async function loadApprovedReviews() {
      try { const r=await fetch('/api.php?action=reviews',{credentials:'same-origin'});if(r.ok){const a=await r.json();const ids=new Set(allFileReviews.map(r=>r.id).filter(Boolean));allFileReviews.unshift(...(a.reviews||[]).filter(r=>!ids.has(r.id)));} } catch(e) {}
      applyAllFilters();
    }
    async function yorumMailGonder(event) {
      event.preventDefault();
      const form=document.getElementById('musteriYorumFormu');
      const payload={author:document.getElementById('yorumIsim').value.trim(),district:document.getElementById('yorumIlce').value.trim(),service:document.getElementById('yorumHizmet').value,rating:parseInt(document.getElementById('yorumPuan').value,10),comment:document.getElementById('yorumMetni').value.trim(),consent:document.getElementById('yorumYayinOnayi').checked,website:document.getElementById('yorumWebsite').value};
      const btn=document.getElementById('yorumGonderBtn');btn.disabled=true;stError('yorumError','');document.getElementById('yorumOnayMsg').classList.add('hidden');btn.innerHTML='<i class="fa-solid fa-circle-notch fa-spin"></i> Kaydediliyor...';
      try{await stApi('review',payload,stRequestKey(form,payload));document.getElementById('yorumOnayMsg').classList.remove('hidden');form.reset();delete form.dataset.requestKey;delete form.dataset.requestBody;}
      catch(e){stError('yorumError',e.name==='AbortError'?'Bağlantı zaman aşımına uğradı. Aynı yorumu tekrar gönderebilirsiniz.':e.message);}
      finally{btn.disabled=false;btn.innerHTML='<i class="fa-solid fa-paper-plane"></i> Yorumu Onaya Gönder';}
    }
    window.addEventListener('DOMContentLoaded',()=>{renderReviewsList(allFileReviews);loadApprovedReviews();});
