'use strict';
window.STNormalizeQuery=value=>String(value).replace(/[çğıöşüÇĞİÖŞÜ]/g,c=>({'ç':'c','ğ':'g','ı':'i','ö':'o','ş':'s','ü':'u','Ç':'C','Ğ':'G','İ':'I','Ö':'O','Ş':'S','Ü':'U'}[c])).toLowerCase().replace(/[^a-z0-9]+/g,' ').trim().replace(/\bkucuk cekmece\b/g,'kucukcekmece').replace(/\bbuyuk cekmece\b/g,'buyukcekmece').replace(/\be c a\b/g,'eca').replace(/\bdemir dokum\b/g,'demirdokum');
window.STResolveQuery=(data,query,preferred='')=>{
  const norm=window.STNormalizeQuery,q=norm(query),has=term=>(' '+q+' ').includes(' '+norm(term)+' ');
  const best=entries=>{let chosen=null,length=-1;for(const entry of entries)for(const term of entry.terms){const n=norm(term);if(n.length>length&&has(n)){chosen=entry;length=n.length}}return chosen};
  const explicit=['klima','klimasi','klimaci'].some(has)?'klima':['kombi','kombisi','kombici','komci'].some(has)?'kombi':'';
  const brandEntries=Object.fromEntries(Object.entries(data.devices).map(([kind,device])=>[kind,device.brands.map(name=>({name,terms:[name,...(data.brand_aliases?.[name]||[])]}))]));
  const brandDevices=Object.keys(brandEntries).filter(kind=>best(brandEntries[kind]));
  const kind=explicit||(data.devices[preferred]?preferred:'')||(brandDevices.length===1?brandDevices[0]:'kombi'),device=data.devices[kind];
  const brand=best(brandEntries[kind]),districtEntry=best(data.districts.map(name=>({name,terms:[name]}))),locality=best(data.localities.map(s=>({...s,terms:[s.name]})));
  let district=districtEntry?.name||locality?.district||'',neighborhood='',ambiguous=false;
  const groups=new Map();for(const r of data.neighborhoods){const n=norm(r.name);if(has(n)){if(!groups.has(n))groups.set(n,[]);groups.get(n).push(r)}}
  const sorted=[...groups].sort((a,b)=>b[0].length-a[0].length),districtHits=data.districts.filter(has),without=(text,d)=>text.replace(new RegExp('\\b'+norm(d)+'\\b'),'');
  const hasIn=(text,term)=>(' '+text+' ').includes(' '+norm(term)+' ');
  for(const [name,rows] of sorted){const consistent=rows.filter(r=>districtHits.includes(r.district)&&((norm(r.name)!==norm(r.district)&&hasIn(norm(r.name),r.district))||hasIn(without(q,r.district),r.name)));if(consistent.length===1){neighborhood=consistent[0].name;district=consistent[0].district;break}}
  const geography=district?without(q,district):q;
  if(!neighborhood)for(const [name,rows] of sorted){const narrowed=rows.filter(r=>(!district||r.district===district)&&hasIn(geography,r.name));if(narrowed.length===1){neighborhood=narrowed[0].name;district=narrowed[0].district;break}if(narrowed.length>1)ambiguous=true}
  if(locality?.name==='500 Evler'&&!districtEntry){district='';neighborhood=''}
  const symptom=best(device.symptoms),service=best(device.services.slice(1)),found=!!(explicit||brand||district||neighborhood||locality||symptom||service);
  return {ok:true,found,query,device:kind,device_label:device.label,brand:brand?.name||'',district,neighborhood,locality:locality?.name||'',path:found?(symptom?.path||service?.path||device.services[0].path):'',symptom:symptom?.name||'',service_path:service?.path||device.services[0].path,scope_check:['yetkili','özel','satış','ikinci el','bayilik','temsilcilik'].some(has),ambiguous_neighborhood:ambiguous&&!neighborhood};
};
