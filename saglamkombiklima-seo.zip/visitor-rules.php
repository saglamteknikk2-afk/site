<?php
declare(strict_types=1);
/** IP hash tabanli 10 gunluk Telegram ziyaret siniri ve 60 gunluk yorum araligi.
 * Ham IP, cihaz numarasi veya musteri kimligi veritabanina kaydedilmez.
 * Ortak IP / dinamik IP kullanimi nedeniyle bir kisiye tekil esleme garantisi vermez. */
function st_visitor_rules_schema(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS visitor_notification_windows(ip_key TEXT PRIMARY KEY, notified_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS review_submission_windows(subject_key TEXT PRIMARY KEY, last_at INTEGER NOT NULL);");
}
function st_visitor_rules_key(string $scope,string $value,string $secret): string {
    return hash_hmac('sha256',$scope."\0".$value,$secret);
}
function st_visitor_rules_page(string $candidate): string {
    $page=explode('?',trim($candidate),2)[0];
    return strlen($page)<=200&&preg_match('#^/[a-zA-Z0-9_./-]*$#D',$page)&&strpos($page,'..')===false?$page:'/';
}
function st_visitor_rules_referer_page(string $referer,string $siteUrl): string {
    $host=parse_url($siteUrl,PHP_URL_HOST);
    return $referer!==''&&is_string($host)&&strcasecmp((string)parse_url($referer,PHP_URL_HOST),$host)===0
        ?st_visitor_rules_page((string)parse_url($referer,PHP_URL_PATH)):'/';
}
/** Read-only fast gate to avoid repeated geolocation lookups for returning visitors.
 * The final decision is still made atomically by queue_visit. */
function st_visitor_rules_notice_due(PDO $db,string $ip,?int $at=null): bool {
    if(filter_var($ip,FILTER_VALIDATE_IP)===false)return false;
    $secret=(string)$db->query("SELECT v FROM meta WHERE k='secret'")->fetchColumn();
    if($secret==='')return false;
    $key=st_visitor_rules_key('notify-10-days',strtolower($ip),$secret);
    $q=$db->prepare('SELECT notified_at FROM visitor_notification_windows WHERE ip_key=?');$q->execute([$key]);
    $last=$q->fetchColumn();return $last===false||(int)$last<=($at??time())-10*86400;
}
/** Both bootstrap and explicit visit call here; transaction serializes concurrent tabs. */
function st_visitor_rules_queue_visit(PDO $db,string $page,string $ip,string $agent,string $approxLocation,bool $enabled,?int $at=null): string {
    if(!$enabled||st_analytics_is_bot($agent)||filter_var($ip,FILTER_VALIDATE_IP)===false)return '';
    $at=$at??time();$secret=(string)$db->query("SELECT v FROM meta WHERE k='secret'")->fetchColumn();
    if($secret==='')return '';
    $key=st_visitor_rules_key('notify-10-days',strtolower($ip),$secret);
    $page=st_visitor_rules_page($page);
    $owner=!$db->inTransaction();
    if(!$owner)throw new LogicException('Ziyaret bildirimi, acik islem icinde baslatilamaz.');
    st_transaction_begin($db);
    try {
        $q=$db->prepare('INSERT INTO visitor_notification_windows(ip_key,notified_at) VALUES(?,?) ON CONFLICT(ip_key) DO UPDATE SET notified_at=excluded.notified_at WHERE notified_at<=?');
        $q->execute([$key,$at,$at-10*86400]);
        if($q->rowCount()!==1){$db->commit();return '';}
        $id='visit:once10:'.bin2hex(random_bytes(12));
        $text="🌐 SİTEYE ZİYARET\n📅 Tarih: ".date('d.m.Y',$at)."\n🕒 Saat: ".date('H:i:s',$at)." (İstanbul)"
            ."\n📍 Yaklaşık bölge: ".$approxLocation
            ."\n📱 Cihaz / tarayıcı: ".st_device($agent)
            ."\n📄 Giriş sayfası: ".$page
            ."\n🔔 Bu IP için yeni bildirim aralığı: 10 gün.";
        st_enqueue($db,$id,['text'=>$text]);
        $db->commit();return $id;
    }catch(Throwable $error){if($db->inTransaction())$db->rollBack();throw $error;}
}
/** Only signed, HttpOnly browser cookie is stored by the browser. */
/** Try this exact notice independently of generic background queue order. */
function st_visitor_rules_schedule_delivery(string $eventId): void {
    if($eventId==='')return;
    register_shutdown_function(static function()use($eventId):void{
        if(function_exists('fastcgi_finish_request'))@fastcgi_finish_request();
        try{st_delivery_attempt($eventId,2);}catch(Throwable $ignored){
            @error_log('Saglam Teknik: ziyaret bildirimi sonraki kuyruk denemesine kaldi.');
        }
    });
}
function st_visitor_rules_feedback_cookie(): string {
    $cookie=(string)($_COOKIE['st_feedback_visitor']??'');
    if(preg_match('/^[a-f0-9]{48}$/D',$cookie))return $cookie;
    $cookie=bin2hex(random_bytes(24));
    $secure=(($_SERVER['HTTPS']??'')==='on')||((int)($_SERVER['SERVER_PORT']??0)===443)||parse_url(st_config()['site_url'],PHP_URL_SCHEME)==='https';
    if(PHP_VERSION_ID>=70300){
        setcookie('st_feedback_visitor',$cookie,['expires'=>time()+365*86400,'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Lax']);
    }else{
        setcookie('st_feedback_visitor',$cookie,time()+365*86400,'/; SameSite=Lax','',$secure,true);
    }
    return $cookie;
}
/** Call only WITHIN the surrounding review INSERT transaction.
 * Returns seconds until allowed; zero claims both keys atomically. */
function st_visitor_rules_claim_review(PDO $db,string $ip,string $browserCookie,?int $at=null): int {
    if(!$db->inTransaction())throw new LogicException('Yorum siniri islem gerektirir.');
    $at=$at??time();$secret=(string)$db->query("SELECT v FROM meta WHERE k='secret'")->fetchColumn();
    if($secret==='')throw new RuntimeException('Yorum limit anahtari yok.');
    $keys=[st_visitor_rules_key('review-browser', $browserCookie,$secret)];
    if(filter_var($ip,FILTER_VALIDATE_IP)!==false)$keys[]=st_visitor_rules_key('review-ip',strtolower($ip),$secret);
    $read=$db->prepare('SELECT last_at FROM review_submission_windows WHERE subject_key=?');
    $wait=0;
    foreach($keys as $key){
        $read->execute([$key]);$old=$read->fetchColumn();
        if($old!==false)$wait=max($wait,max(0,(int)$old+60*86400-$at));
    }
    if($wait>0)return $wait;
    $write=$db->prepare('INSERT INTO review_submission_windows(subject_key,last_at) VALUES(?,?) ON CONFLICT(subject_key) DO UPDATE SET last_at=excluded.last_at');
    foreach($keys as $key)$write->execute([$key,$at]);
    return 0;
}
function st_visitor_rules_cleanup(PDO $db,?int $at=null): void {
    $at=$at??time();
    $db->prepare('DELETE FROM visitor_notification_windows WHERE notified_at<?')->execute([$at-11*86400]);
    $db->prepare('DELETE FROM review_submission_windows WHERE last_at<?')->execute([$at-61*86400]);
}
