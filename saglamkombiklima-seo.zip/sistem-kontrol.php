<?php
/** Sağlam Teknik — yalnızca Plesk PHP CLI ile çalıştırılır.
 *  php sistem-kontrol.php
 *  Müşteri verisi ve anahtar göstermez, ağ isteği yapmaz, veritabanı oluşturmaz.
 *  Çıktıyı private/saglam-teknik/teknik-durum.txt dosyasına yazar.
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
define('ST_DIAGNOSTIC_LIBRARY_MODE', true);
require_once __DIR__.'/kurulum-kontrol.php';

function st_durum_satiri(string $title, bool $status, string $note=''): string {
    return ($status?'[TAMAM] ':'[KONTROL] ').$title.($note!==''?' — '.$note:'')."\n";
}
function st_durum_config_exists(string $private): array {
    $file=is_file($private.'/site_apileri,.txt')?$private.'/site_apileri,.txt':$private.'/site_apileri.txt';
    $result=['config'=>false,'telegram_bot'=>false,'telegram_chat'=>false,'gemini'=>false];
    if(!is_file($file)||!is_readable($file)||filesize($file)>65536)return $result;
    $result['config']=true;
    $raw=file_get_contents($file);
    foreach(preg_split('/\r\n|\n|\r/',(string)$raw) as $line){
        if(!preg_match('/^\s*(TELEGRAM_BOT_TOKEN|TELEGRAM_CHAT_ID|GEMINI_API_KEY(?:_[1-4])?)\s*=\s*(.*)$/i',$line,$match))continue;
        $filled=trim($match[2]," \t\"'")!=='';
        if(strtoupper($match[1])==='TELEGRAM_BOT_TOKEN')$result['telegram_bot']=$filled;
        if(strtoupper($match[1])==='TELEGRAM_CHAT_ID')$result['telegram_chat']=$filled;
        if(strpos(strtoupper($match[1]),'GEMINI_API_KEY')===0)$result['gemini']=$result['gemini']||$filled;
    }
    return $result;
}

try {
    $result=st_installation_diagnostics(__DIR__);
    $private=(string)$result['private_directory'];
    $config=st_durum_config_exists($private);
    $runtime=$result['runtime'];$db=$result['storage'];
    $report="SAĞLAM TEKNİK — SİSTEM KONTROLÜ\n";
    $report.='Kontrol zamanı: '.$result['checked_at_istanbul']." (İstanbul)\n";
    $report.="Yalnızca yerel okuma; gerçek Telegram mesajı gönderilmedi.\n\n";
    $report.=st_durum_satiri('Çalışan PHP sürümü',version_compare(PHP_VERSION,'8.2','>='),'PHP '.PHP_VERSION);
    $report.=st_durum_satiri('SQLite sürücüsü',(bool)$runtime['pdo_sqlite'],'Servis kaydı ve yorum için gereklidir');
    $report.=st_durum_satiri('cURL',(bool)$runtime['curl'],'Telegram ve Gemini bağlantıları için gereklidir');
    $report.=st_durum_satiri('Özel dizin web kökü dışında',(bool)$result['private_outside_webroot']);
    $report.=st_durum_satiri('Özel dizin yazılabilir',(bool)$result['private_writable']);
    $report.=st_durum_satiri('API ayar dosyası mevcut',$config['config']);
    $report.=st_durum_satiri('Telegram bot anahtarı girilmiş',$config['telegram_bot'],'Anahtarın değeri gösterilmez');
    $report.=st_durum_satiri('Telegram sohbet kimliği girilmiş',$config['telegram_chat'],'Sohbet kimliği gösterilmez');
    $report.=st_durum_satiri('Gemini anahtarı girilmiş',$config['gemini'],'Bağlantı veya kredi ayrıca doğrulanmalıdır');
    $report.=st_durum_satiri('SQLite veritabanı yolu seçilebiliyor',!empty($db['ok']));
    if(empty($db['ok']))$report.='Veritabanı açıklaması: '.($db['error']??'Seçim başarısız')."\n";
    $report.="\nSON API HATALARI\n";
    $file=$private.'/api-hata-acik.txt';
    if(is_file($file)&&is_readable($file)){
        $lines=file($file,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES);
        $recent=array_slice(is_array($lines)?$lines:[],-42);
        $report.=implode("\n",$recent)."\n";
    } else {
        $legacy=$private.'/api-hata-guvenli.log';
        if(is_file($legacy)&&is_readable($legacy)){
            $lines=file($legacy,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES);
            $report.=implode("\n",array_slice(is_array($lines)?$lines:[],-12))."\n";
            $report.="Bu eski günlükte hata açıklaması yoktu. Yeni destek kodları açıklamalı günlüğe yazılacak.\n";
        } else $report.="Henüz API hata günlüğü yok.\n";
    }
    $report.="\nYAPILACAK KONTROL\n";
    $report.="1. PHP-FPM ve Plesk CLI PHP sürümlerinin aynı olduğundan emin olun.\n";
    $report.="2. Servis veya yorum gönderirken çıkan yeni destek kodunu api-hata-acik.txt dosyasında arayın.\n";
    $report.="3. Servis/yorum kaydı başarılıysa Telegram kuyruğunu 'php worker.php status' ile kontrol edin.\n";
    $report.="4. Gerçek teslim için ayrıca 'php worker.php test-telegram' çalıştırın.\n";
    $report.="5. SQLite veya ayar dosyasını silmeyin.\n";
    if(!empty($result['private_outside_webroot'])&&!empty($result['private_writable'])){
        $dest=$private.'/teknik-durum.txt';
        if(file_put_contents($dest,$report,LOCK_EX)!==false){@chmod($dest,0600);$report.="\nRapor, özel dizindeki teknik-durum.txt dosyasına kaydedildi.\n";}
    }
    echo $report;
} catch(Throwable $error) {
    fwrite(STDERR,'Sistem kontrolü yapılamadı ('.get_class($error).'): kurulum-kontrol.php ve özel dizin yolunu denetleyin.' . "\n");
    exit(1);
}
