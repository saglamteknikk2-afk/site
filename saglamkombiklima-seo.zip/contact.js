'use strict';
function contactPayload(){
 const el=id=>document.getElementById(id),model=el('contactModel').value.trim();
 return {name:el('contactName').value.trim(),phone:el('contactPhone').value.trim(),district:el('contactDistrict').value.trim(),device:el('contactDevice').value,issue:((model?'Marka/model: '+model+' · ':'')+el('contactIssue').value.trim()).slice(0,2000),website:el('contactWebsite').value};
}
function updateContactWhatsapp(){const data=contactPayload(),link=document.getElementById('contactWhatsApp');if(link)link.href='https://wa.me/905346225515?text='+encodeURIComponent('Merhaba Sağlam Teknik, '+data.device+' servis talebim var. '+(data.district?'Konum: '+data.district+'. ':'')+data.issue);}
async function submitContactRequest(event){
 event.preventDefault();const form=document.getElementById('contactForm'),button=document.getElementById('contactSubmit'),status=document.getElementById('contactStatus');if(button.disabled)return;
 const data=contactPayload();button.disabled=true;status.textContent='Talebiniz kaydediliyor…';
 try{const result=await stApi('ticket',data,stRequestKey(form,data));status.textContent=result.message||'Talebiniz kaydedildi. Hızlı dönüş için bizi arayabilirsiniz.';delete form.dataset.requestKey;delete form.dataset.requestBody;form.reset();updateContactWhatsapp();}
 catch(error){status.textContent=error.name==='AbortError'?'Bağlantı zaman aşımına uğradı. Bilgileriniz duruyor; aynı talebi tekrar gönderebilirsiniz.':error.message;}
 finally{button.disabled=false;}
}
window.addEventListener('DOMContentLoaded',()=>{
 const form=document.getElementById('contactForm');if(!form)return;
 const params=new URLSearchParams(location.search||location.hash.slice(1)),el=id=>document.getElementById(id);
 const kind=params.get('cihaz');if(kind==='klima')el('contactDevice').value='Klima';else if(kind==='petek')el('contactDevice').value='Petek';
 el('contactDistrict').value=[params.get('ilce'),params.get('mahalle'),params.get('semt')].filter(Boolean).join(' / ').slice(0,120);
 el('contactModel').value=(params.get('marka')||'').slice(0,150);
 const requested=params.get('islem'),serviceNames={'/kombi-servisi.html':'Kombi servisi','/kombi-tamiri.html':'Kombi tamiri','/kombi-bakimi.html':'Kombi bakımı','/klima-servisi.html':'Klima servisi','/klima-tamiri.html':'Klima tamiri','/klima-bakimi.html':'Klima bakımı','/klima-montaji.html':'Klima montajı','/klima-sokumu.html':'Klima sökümü','/klima-gaz-kontrolu.html':'Klima gaz ve kaçak kontrolü'};
 el('contactIssue').value=[serviceNames[requested]||'',params.get('belirti')||params.get('arama')||''].filter(Boolean).join(' · ').slice(0,1500);
 updateContactWhatsapp();form.addEventListener('input',updateContactWhatsapp);
});
