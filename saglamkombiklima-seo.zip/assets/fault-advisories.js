'use strict';
// Manufacturer advisory lookup only. No DOM, network, or ordinary fault-code inference.
(() => {
  const fold = value => String(value).toLowerCase().normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'').replace(/ı/g,'i')
    .replace(/([a-z])([0-9])/g,'$1 $2').replace(/([0-9])([a-z])/g,'$1 $2')
    .replace(/[^a-z0-9.,]+/g,' ').replace(/\s+/g,' ').trim();
  const isExactNoticeModel = name => /^gunes\s*premix\s+35\s+kw$/.test(fold(name));
  window.STFaultAdvisory = query => {
    if(typeof query!=='string')return null;
    const text=fold(query);
    if(!/\bbaykan\b/.test(text)||/\bbaymak\b/.test(text))return null;
    if(!/\bgunes\s*premix\b/.test(text)||/\b(?:saturn|lena|luxury)\b/.test(text))return null;
    const capacities=[...text.matchAll(/(?:^|[^a-z0-9.,])(\d+(?:[.,]\d+)?)\s*(?:kw|kilovat(?:t)?|kilowatt)(?=$|[^a-z0-9])/g)]
      .map(match=>Number(match[1].replace(',','.')));
    // A bare 35, another unit, or mixed capacities cannot establish the recalled variant.
    if(!capacities.length||capacities.some(value=>value!==35))return null;
    const coverage=window.ST_VERIFIED_FAULTS?.coverage;
    if(!Array.isArray(coverage))return null;
    const brand=coverage.find(item=>item.device==='kombi'&&fold(item.brand)==='baykan');
    const notice=(brand?.advisories||[]).find(item=>item.kind==='recall'
      &&Array.isArray(item.exact_model_names)&&item.exact_model_names.some(isExactNoticeModel)
      &&/^https:\/\/(?:www\.)?baykankombi\.com(?:\/|$)/.test(item.url||'')
      &&typeof item.message==='string'&&item.message.trim()&&item.source_locator);
    if(!notice)return null;
    return {ok:true,source:'advisory',manufacturer_advisory:true,text:notice.message,
      source_url:notice.url,source_locator:notice.source_locator,guide_path:'model-ariza-kodlari.html'};
  };
})();
