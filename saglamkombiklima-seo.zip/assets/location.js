'use strict';
(()=>{
 let current=null,version=0;
 function status(message){document.querySelectorAll('[data-st-location-status]').forEach(e=>e.textContent=message)}
 window.stAttachLocation=data=>{if(data&&typeof data==='object'){if(current)data.location={...current};else delete data.location}return data};
 async function share(){
  if(!navigator.geolocation){status('Tarayıcınız konum paylaşımını desteklemiyor. İlçe ve mahalle seçimiyle devam edebilirsiniz.');return}
  const request=++version;status('Konum için tarayıcı izni bekleniyor…');
  navigator.geolocation.getCurrentPosition(async p=>{
   if(request!==version)return;
   current={consent:true,latitude:Number(p.coords.latitude.toFixed(6)),longitude:Number(p.coords.longitude.toFixed(6)),accuracy:Math.round(p.coords.accuracy)};
   status('Konumunuz talebinize eklenir. Konumunuz iletiliyor…');
   try{await stApi('visit',{page:location.pathname,location:{...current}});if(request===version)status('Konum kaydedildi. Talebinize de eklenecek.')}
   catch(e){if(request===version)status('Konum forma eklendi. Talebinizi gönderebilirsiniz.')}
  },()=>{if(request===version)status('Konum alınamadı. İlçe ve mahalle seçimiyle devam edebilirsiniz.')},{enableHighAccuracy:true,timeout:12000,maximumAge:0});
 }
 window.addEventListener('DOMContentLoaded',()=>document.querySelectorAll('[data-st-location-host]').forEach(host=>{
  const box=document.createElement('div');box.className='st-location-widget';
  box.innerHTML='<p>İsterseniz servis konumunuzu paylaşın. Kesin konum için tarayıcınız izin ister.</p><button type="button" data-share>Konumumu paylaş</button> <button type="button" data-clear>Konumu kaldır</button><p data-st-location-status role="status" aria-live="polite">İlçe ve mahalleyi seçerek de talep bırakabilirsiniz.</p>';
  box.querySelector('[data-share]').addEventListener('click',share);
  box.querySelector('[data-clear]').addEventListener('click',()=>{version++;current=null;status('Sonraki taleplerden konum kaldırıldı. Önceden gönderilmiş bildirim silinmez.')});host.append(box);
 }));
})();
