'use strict';
(()=>{
 if(location.protocol==='file:'||typeof stApi!=='function'||typeof stToken!=='function'||typeof stId!=='function')return;
 const page=String(location.pathname||'/').slice(0,160);
 if(!/^\/[a-zA-Z0-9_./-]*$/.test(page)||page.includes('..'))return;
 const interval=25000,maximum=45000;
 let token='',state;
 const foreground=()=>document.visibilityState!=='hidden'&&document.hasFocus();
 function accrue(s){
  const now=performance.now();
  if(s.since!==null)s.credit=Math.min(maximum,s.credit+Math.max(0,now-s.since));
  s.since=foreground()&&!s.ended?now:null;
 }
 function payload(s,event){
  const active_ms=event==='view'?0:Math.min(maximum,Math.floor(s.credit));
  s.credit-=active_ms;
  return {event,page,view_id:s.id,seq:++s.seq,active_ms};
 }
 function schedule(s){
  if(s.timer!==null){clearTimeout(s.timer);s.timer=null;}
  if(s.ended||!foreground())return;
  s.timer=setTimeout(()=>{s.timer=null;if(s.ended)return;accrue(s);if(foreground()){flush(s,'pulse');schedule(s);}},interval);
 }
 async function flush(s,event){
  if(s.ended||s.busy||s.seq>=1000000000)return;
  accrue(s);if(!s.pending)s.pending=payload(s,event);
  const pending=s.pending;s.busy=true;
  try{
   if(!token)token=await stToken();
   if(s.ended||(pending.event==='pulse'&&!foreground()))return;
   await stApi('activity',pending);
   if(s.pending===pending)s.pending=null;
  }catch(e){/* Aynı ölçüm bir sonraki görünür aralıkta aynı sıra numarasıyla denenir. */}
  finally{s.busy=false;}
 }
 function start(){
  state={id:stId(),seq:0,credit:0,since:foreground()?performance.now():null,pending:null,busy:false,timer:null,ended:false};
  flush(state,'view');schedule(state);
 }
 function focusChanged(){if(!state||state.ended)return;accrue(state);schedule(state);}
 document.addEventListener('visibilitychange',focusChanged);
 window.addEventListener('focus',focusChanged);window.addEventListener('blur',focusChanged);
 window.addEventListener('pagehide',()=>{
  const s=state;if(!s||s.ended)return;
  accrue(s);s.ended=true;s.since=null;schedule(s);
  const csrf=typeof stCsrf==='string'&&stCsrf?stCsrf:token;
  if(!csrf||s.seq>=1000000000)return;
  const end=payload(s,'end');
  try{fetch('api.php?action=activity',{method:'POST',credentials:'same-origin',keepalive:true,headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(end)}).catch(()=>{});}catch(e){}
 });
 window.addEventListener('pageshow',event=>{if(event.persisted)start();});
 start();
})();
