'use strict';
// Turkish search terms are normalized for matching, never used to create new URLs.
window.STNormalizeQuery = value => String(value ?? '')
  .replace(/[çğıöşüÇĞİÖŞÜ]/g, c => ({ç:'c',ğ:'g',ı:'i',ö:'o',ş:'s',ü:'u',Ç:'C',Ğ:'G',İ:'I',Ö:'O',Ş:'S',Ü:'U'}[c]))
  .toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim()
  .replace(/\bkucuk\s+cekmece\b/g, 'kucukcekmece')
  .replace(/\bbuyuk\s+cekmece\b/g, 'buyukcekmece')
  .replace(/\bkucukcekm[e]?ce(?:ce)?\b/g, 'kucukcekmece')
  .replace(/\bkucukcekmecece\b/g, 'kucukcekmece')
  .replace(/\be\s+c\s+a\b/g, 'eca')
  .replace(/\bdemir\s+dokum\b/g, 'demirdokum');

window.STResolveQuery = (data, query, preferred = '') => {
  const norm = window.STNormalizeQuery;
  const q = norm(query), catalog = window.ST_ORGANIC_CATALOG || {};
  const has = term => !!norm(term) && (' ' + q + ' ').includes(' ' + norm(term) + ' ');
  const best = entries => {
    let chosen = null, length = -1;
    for (const entry of entries) for (const term of entry.terms || []) {
      const n = norm(term);
      if (n.length > length && has(n)) { chosen = entry; length = n.length; }
    }
    return chosen;
  };
  const explicit = ['klima','klimasi','klimaci'].some(has) ? 'klima'
    : ['kombi','kombisi','kombici','komci'].some(has) ? 'kombi' : '';
  const brandEntries = Object.fromEntries(Object.entries(data.devices).map(([kind, device]) => [kind,
    device.brands.map(name => ({name, terms: [name, ...(data.brand_aliases?.[name] || [])]}))]));
  const brandDevices = Object.keys(brandEntries).filter(kind => best(brandEntries[kind]));
  const engine = window.STFaults;
  // A model may identify its brand even when the visitor omitted that word.
  // Only a unique documented match is used; an unknown family is never guessed.
  const inferred = engine ? Object.keys(data.devices).map(device =>
    engine.infer(query,device,best(brandEntries[device])?.name || '')).filter(Boolean) : [];
  const uniqueInferred = inferred.length === 1 ? inferred[0] : null;
  const modelEntries = (catalog.models || []).filter(model => has(model.brand));
  const recognizedModel = best(modelEntries);
  const kind = explicit || uniqueInferred?.device || recognizedModel?.device
    || (brandDevices.length === 1 ? brandDevices[0] : '')
    || (data.devices[preferred] ? preferred : 'kombi');
  const device = data.devices[kind];
  const explicitBrand = best(brandEntries[kind]);
  const inferredModel = engine?.infer(query,kind,explicitBrand?.name || '') || null;
  const brand = explicitBrand || (inferredModel ? {name:inferredModel.brand} : null);
  const districtEntry = best(data.districts.map(name => ({name,terms:[name]})));
  const locality = best(data.localities.map(s => ({...s,terms:[s.name]})));
  let district = districtEntry?.name || locality?.district || '', neighborhood = '', ambiguous = false;
  const groups = new Map();
  for (const row of data.neighborhoods) {
    const name = norm(row.name);
    if (has(name)) { if (!groups.has(name)) groups.set(name, []); groups.get(name).push(row); }
  }
  const sorted = [...groups].sort((a,b) => b[0].length-a[0].length);
  const districtHits = data.districts.filter(has);
  const without = (text,d) => text.replace(new RegExp('\\b' + norm(d) + '\\b'), '');
  const hasIn = (text,term) => (' '+text+' ').includes(' '+norm(term)+' ');
  for (const [,rows] of sorted) {
    const consistent = rows.filter(row => districtHits.includes(row.district)
      && ((norm(row.name) !== norm(row.district) && hasIn(norm(row.name),row.district))
        || hasIn(without(q,row.district),row.name)));
    if (consistent.length === 1) { neighborhood = consistent[0].name; district = consistent[0].district; break; }
  }
  const geography = district ? without(q,district) : q;
  if (!neighborhood) for (const [,rows] of sorted) {
    const narrowed = rows.filter(row => (!district || row.district === district) && hasIn(geography,row.name));
    if (narrowed.length === 1) { neighborhood = narrowed[0].name; district = narrowed[0].district; break; }
    if (narrowed.length > 1) ambiguous = true;
  }
  if (locality?.name === '500 Evler' && !districtEntry) { district = ''; neighborhood = ''; ambiguous = true; }

  const codeContext = !!explicit || !!brand || !!inferredModel
    || ['hata','hatasi','hata kodu','ariza','arizasi','ariza kodu'].some(has);
  const fallbackTokens = q.match(/\b[a-z]{1,2}\s*\d{1,3}\b/g) || [];
  const fallbackCandidates = fallbackTokens.map(value => value.replace(/\s+/g,'').toUpperCase())
    .filter(value => /^(?:E|F|A|C|CH|H|J|L|P|U|EA|EC)\d{1,3}$/.test(value));
  const standaloneCode = q.match(/\b(?:ea|ec)\b/);
  const numericCode = q.match(/\b(?:hata|ariza|kod|kodu)\s+(\d{2,4})\b/);
  const fallbackCode = fallbackCandidates[0] || standaloneCode?.[0].toUpperCase() || numericCode?.[1] || '';
  const fault = engine?.lookup({device:kind,brand:brand?.name || '',
    model_id:inferredModel?.id || '',query}) || null;
  const errorCode = codeContext ? fault?.code || fallbackCode : '';
  const model = fault?.model?.label || (recognizedModel?.device === kind
    && recognizedModel?.brand === brand?.name ? recognizedModel.name || '' : '');
  const matchedGuide = (catalog.guides || []).find(guide => guide.status === 'published'
    && !guide.model_id && guide.device === kind && guide.brand === brand?.name
    && guide.error_code === errorCode && (!guide.model || norm(guide.model) === norm(model)));
  const errorIntent = !!errorCode || ['hata kodu','ariza kodu','hata kod','ariza kod'].some(has);
  const verified = !!fault?.verified;
  const definition = verified ? fault.definition : null;
  const faultModelPath = fault?.model?.path && /^\/[a-z0-9-]+\.html$/.test(fault.model.path)
    ? fault.model.path : '';
  const faultAnchor = definition?.anchor || (definition && engine
    ? 'kod-'+engine.codeKey(definition.code).toLowerCase() : '');
  const verifiedPath = verified && faultModelPath ? faultModelPath+'#'+faultAnchor : '';
  const symptom = best(device.symptoms), service = best(device.services.slice(1));
  const allowed = new Set(catalog.published_routes || []);
  const slug = value => norm(value).replace(/\s+/g,'-');
  const knownPath = path => allowed.has(path) ? path : '';
  const districtPath = district ? knownPath('/'+slug(district)+'-'+kind+'-servisi.html') : '';
  const localityPath = locality ? knownPath('/'+slug(locality.name)+'-servisi.html') : '';
  const brandPath = brand ? knownPath('/'+slug(brand.name)+'-'+kind+'-servisi.html') : '';
  const errorPath = errorIntent ? verifiedPath || faultModelPath || matchedGuide?.path || catalog.general_error_paths?.[kind]
    || (kind === 'klima' ? 'klima-hata-kodu.html' : 'kombi-calismiyor.html') : '';
  const found = !!(explicit || brand || district || neighborhood || locality || symptom || service || errorIntent);
  const path = found ? errorPath || symptom?.path || service?.path || localityPath || districtPath
    || brandPath || device.services[0].path : '';
  return {
    ok:true, found, query, device:kind, device_label:device.label, brand:brand?.name || '',
    district, neighborhood, locality:locality?.name || '', path,
    symptom:symptom?.name || '', service_path:service?.path || device.services[0].path,
    scope_check:['yetkili','ozel','satis','ikinci el','bayilik','temsilcilik'].some(has),
    ambiguous_neighborhood:ambiguous && !neighborhood, model, error_code:errorCode,
    error_guide_path:errorPath,
    content_status:verified ? 'verified-model-guide' : errorIntent && faultModelPath ? 'model-guide'
      : matchedGuide ? 'published-guide' : errorIntent ? 'general-guide' : 'published',
    model_id:fault?.model?.id || '', fault_status:fault?.status || (errorIntent ? 'needs-model' : 'not-requested'),
    model_required:!!errorIntent && !verified, needs_model:!!errorIntent && !verified,
    code_definition_verified:verified, fault_meaning:definition?.meaning || '',
    source_url:verified ? definition?.source_url || fault?.model?.manual?.url || '' : '',
    source_locator:verified ? definition?.source_locator || fault?.model?.manual?.locator || '' : ''
  };
};
