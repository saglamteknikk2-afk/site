/* Shared editorial site navigation. No remote dependencies. */
(() => {
  'use strict';

  function onReady() {
    if (!document.body.classList.contains('at-site')) return;

    const toggle = document.getElementById('atMenuToggle');
    const navigation = document.getElementById('atNavigation');
    const desktop = window.matchMedia('(min-width: 1000px)');

    if (toggle && navigation) {
      toggle.setAttribute('aria-controls', navigation.id);
      let open = false;

      function setOpen(next, returnFocus = false) {
        open = Boolean(next) && !desktop.matches;
        navigation.classList.toggle('is-open', open);
        toggle.classList.toggle('is-open', open);
        toggle.setAttribute('aria-expanded', String(open));
        if (desktop.matches) navigation.removeAttribute('aria-hidden');
        else navigation.setAttribute('aria-hidden', String(!open));
        if (returnFocus && !desktop.matches) toggle.focus();
      }

      toggle.addEventListener('click', () => setOpen(!open));
      navigation.addEventListener('click', event => {
        if (event.target.closest('a[href]')) setOpen(false);
      });
      document.addEventListener('click', event => {
        if (open && !navigation.contains(event.target) && !toggle.contains(event.target)) {
          setOpen(false);
        }
      });
      document.addEventListener('keydown', event => {
        if (event.key === 'Escape' && open) {
          event.preventDefault();
          setOpen(false, true);
        }
      });
      document.addEventListener('focusin', event => {
        if (open && !navigation.contains(event.target) && !toggle.contains(event.target)) {
          setOpen(false);
        }
      });
      const resetMenu = () => setOpen(false);
      if (desktop.addEventListener) desktop.addEventListener('change', resetMenu);
      else desktop.addListener(resetMenu);
      setOpen(false);
    }

    function normalizedPath(path) {
      return path.replace(/\/index\.html$/i, '/').replace(/\/$/, '') || '/';
    }

    if (navigation) {
      const currentPath = normalizedPath(window.location.pathname);
      navigation.querySelectorAll('a[href]').forEach(link => {
        let target;
        try { target = new URL(link.getAttribute('href'), window.location.href); }
        catch (_) { return; }
        if (target.origin !== window.location.origin || target.hash) return;
        const current = normalizedPath(target.pathname) === currentPath;
        link.classList.toggle('is-current', current);
        if (current) link.setAttribute('aria-current', 'page');
        else if (link.getAttribute('aria-current') === 'page') link.removeAttribute('aria-current');
      });
    }

    document.querySelectorAll('.at-toc').forEach(toc => {
      if (toc.querySelector('a[href]')) return;
      const headings = [...document.querySelectorAll('.at-content h2')].filter(heading => {
        if (!heading.textContent.trim() || heading.closest('[hidden], .hidden, [aria-hidden="true"]')) return false;
        const style = window.getComputedStyle(heading);
        return style.display !== 'none' && style.visibility !== 'hidden' && heading.getClientRects().length > 0;
      }).slice(0, 12);
      if (!headings.length) return;

      if (!toc.querySelector('.at-aside-label')) {
        const label = document.createElement('p');
        label.className = 'at-aside-label';
        label.textContent = 'Bu sayfada';
        toc.append(label);
      }
      const list = document.createElement('ul');
      list.className = 'at-toc-list';
      headings.forEach((heading, index) => {
        if (!heading.id) {
          const stem = heading.textContent.trim().toLocaleLowerCase('tr')
            .replace(/ı/g, 'i').normalize('NFKD').replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || `bolum-${index + 1}`;
          const base = `at-${stem}`;
          let id = base;
          let suffix = 2;
          while (document.getElementById(id)) id = `${base}-${suffix++}`;
          heading.id = id;
        }
        const item = document.createElement('li');
        const link = document.createElement('a');
        link.setAttribute('href', `#${encodeURIComponent(heading.id)}`);
        link.textContent = heading.textContent.trim();
        item.append(link);
        list.append(item);
      });
      toc.append(list);
    });

    const tocLinks = [...document.querySelectorAll('.at-toc a[href*="#"]')];
    const sections = new Map();
    tocLinks.forEach(link => {
      let target;
      try { target = new URL(link.getAttribute('href'), window.location.href); }
      catch (_) { return; }
      if (target.origin !== window.location.origin ||
          normalizedPath(target.pathname) !== normalizedPath(window.location.pathname) ||
          !target.hash) return;
      let id;
      try { id = decodeURIComponent(target.hash.slice(1)); }
      catch (_) { return; }
      const section = document.getElementById(id);
      if (!section) return;
      if (!sections.has(section)) sections.set(section, []);
      sections.get(section).push(link);
      link.addEventListener('click', () => markSection(section));
    });

    function markSection(section) {
      sections.forEach((links, element) => links.forEach(link => {
        const current = element === section;
        link.classList.toggle('is-active', current);
        if (current) link.setAttribute('aria-current', 'location');
        else if (link.getAttribute('aria-current') === 'location') link.removeAttribute('aria-current');
      }));
    }

    if (!sections.size) return;
    const orderedSections = [...sections.keys()];
    const initialHash = (() => {
      try { return decodeURIComponent(window.location.hash.slice(1)); }
      catch (_) { return ''; }
    })();
    markSection(orderedSections.find(section => section.id === initialHash) || orderedSections[0]);

    if ('IntersectionObserver' in window) {
      const visible = new Set();
      const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) visible.add(entry.target);
          else visible.delete(entry.target);
        });
        const candidates = orderedSections.filter(section => visible.has(section));
        if (candidates.length) {
          candidates.sort((a, b) => Math.abs(a.getBoundingClientRect().top - 120) -
            Math.abs(b.getBoundingClientRect().top - 120));
          markSection(candidates[0]);
        }
      }, { rootMargin: '-15% 0px -60% 0px', threshold: 0 });
      orderedSections.forEach(section => observer.observe(section));
    }
    window.addEventListener('hashchange', () => {
      let id;
      try { id = decodeURIComponent(window.location.hash.slice(1)); }
      catch (_) { return; }
      const section = orderedSections.find(item => item.id === id);
      if (section) markSection(section);
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', onReady, { once: true });
  else onReady();
})();
