'use strict';
document.addEventListener('DOMContentLoaded',()=>{
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const api=window.STFaults;if(!api)return;
  const input=document.getElementById('faultTableSearch');
  if(input){
    const rows=[...document.querySelectorAll('[data-fault-row]')],status=document.getElementById('faultTableStatus');
    input.addEventListener('input',()=>{const q=input.value.trim(),codeLike=/\d/.test(q)&&/^[A-Za-z0-9.\s-]+$/.test(q);let count=0;for(const row of rows){const match=!q||(codeLike?api.codeKey(row.querySelector('code').textContent)===api.codeKey(q):api.normalize(row.textContent).includes(api.normalize(q)));row.hidden=!match;if(match)count++;}status.textContent=count+' gösterim listeleniyor.';});
  }
  const guideSearch=document.getElementById('faultGuideSearch');
  if(guideSearch)guideSearch.addEventListener('input',()=>{const q=api.normalize(guideSearch.value);document.querySelectorAll('[data-model-card]').forEach(card=>card.hidden=!api.normalize(card.textContent).includes(q));});
  if(!document.getElementById('faultBrowser'))return;
  const el=id=>document.getElementById(id),data=window.ST_VERIFIED_FAULTS;
  const device=()=>el('faultDevice').value;
  function modelOptions(selected=''){
    const list=api.models(device(),el('faultBrand').value);el('faultModel').replaceChildren(new Option('Tam model / belge ailesini seçin',''),...list.map(m=>new Option(m.label,m.id)));el('faultModel').value=list.some(m=>m.id===selected)?selected:'';
    el('faultModel').disabled=list.length===0;el('faultScope').checked=false;scope();
  }
  function brandOptions(selected=''){
    const brands=[...new Set(data.coverage.filter(x=>x.device===device()).map(x=>x.brand))].sort((a,b)=>a.localeCompare(b,'tr'));
    el('faultBrand').replaceChildren(new Option('Marka seçin',''),...brands.map(b=>new Option(b,b)));el('faultBrand').value=brands.includes(selected)?selected:'';modelOptions();
  }
  function scope(){
    const m=api.models(device(),el('faultBrand').value).find(m=>m.id===el('faultModel').value),wrap=el('faultScopeWrap');
    wrap.hidden=!m?.requires_scope_confirmation||m?.matchable===false;
    let detail=el('faultScopeDetails');if(!detail){detail=document.createElement('p');detail.id='faultScopeDetails';detail.className='fault-small';wrap.before(detail);}
    detail.replaceChildren();detail.hidden=!m;
    if(m){detail.append(document.createTextNode([m.market,m.scope_note,m.manual.title,m.manual.document_id||m.manual.document_number].filter(Boolean).join(' · ')+' '));const link=document.createElement('a');link.href=m.manual.url;link.target='_blank';link.rel='noopener noreferrer';link.textContent='Seçilen üretici belgesini aç ↗';detail.append(link);}
    el('faultAnswer').textContent='';
  }
  function show(){
    const model=api.models(device(),el('faultBrand').value).find(m=>m.id===el('faultModel').value);
    const result=api.lookup({device:device(),brand:el('faultBrand').value,model_id:el('faultModel').value,code:el('faultCode').value.trim(),scope_confirmed:el('faultScope').checked});
    const box=el('faultAnswer');
    if(!el('faultBrand').value){box.textContent='Önce cihazınızın markasını seçin.';return;}
    if(!model){
      const candidates=api.models(device(),el('faultBrand').value);box.textContent=candidates.length?'Marka bilgisi tek başına yeterli değil. Etiketteki tam modelle eşleşen belgeyi seçin.':'Bu marka için modelinizin kendi üretici belgesini birlikte kontrol edelim. Etiketteki tam model, kapasite ve ürün kodunu not edin; benzer markanın tablosunu kullanmayın.';return;
    }
    if(result.status==='scope-required'){box.textContent='Bu belgenin ülke/ürün kodu veya kontrol cihazı kapsamı ayrıca doğrulanmalıdır. Etiket ve belge eşleşiyorsa onay kutusunu işaretleyin; emin değilseniz başka bir model seçerek tahmin etmeyin.';return;}
    if(result.status==='document-match-required'){box.innerHTML='<p>Bu belgede model adı yeterince ayırt edici değil. Kapasiteye bakarak bir anlam eşleştirmiyoruz; üreticinin belge/ürün numarasıyla kontrol edin.</p><a href="'+esc(model.path)+'">Belge kapsamını incele →</a>';return;}
    if(!result.code){box.innerHTML='<h3>'+esc(model.brand+' '+model.label)+'</h3><p>Ekrandaki kodu baştaki sıfırlar ve alt kodlarla birlikte yazın.</p><a href="'+esc(model.path)+'">Bu modelin kod tablosunu aç →</a>';return;}
    if(result.status==='source-conflict'){box.innerHTML='<h3>'+esc(result.code)+'</h3><p>'+esc(result.definition?.conflict_note||'Üretici kaynağında bu gösterim birden fazla açıklamayla yer alıyor. Otomatik bir anlam seçilmedi; tam belge ve cihaz varyantı teknik olarak kontrol edilmeli.')+'</p><a href="'+esc(model.path)+'">Kaynağı ve kapsamı incele →</a>';return;}
    if(!result.verified){box.innerHTML='<h3>'+esc(result.code)+' · '+esc(model.brand+' '+model.label)+'</h3><p>Bu modelin incelenen belgesinde bu gösterim için doğrulanmış bir eşleşme yok. Başka modelin aynı kodunu bu cihaza uygulamayın; ekrandaki yazımı ve belgenin sürümünü kontrol edin.</p><a href="'+esc(model.path)+'">Model kapsamını incele →</a>';return;}
    const code=result.definition,url=code.source_url||model.manual.url;
    box.innerHTML='<p class="fault-kicker">SEÇTİĞİNİZ MODELİN ÜRETİCİ BELGESİ</p><h3>'+esc(result.code)+' · '+esc(model.brand+' '+model.label)+'</h3><p>'+esc(code.meaning)+'</p><p>'+esc(code.safe_observation)+'</p><p class="fault-small">Bu açıklama kesin parça teşhisi değildir. Kapağı açmayın; gaz, elektrik ve soğutucu devreye müdahale etmeyin.</p><a href="'+esc(url)+'" target="_blank" rel="noopener noreferrer">Üretici kaynağı ↗</a><small>'+esc(code.source_locator)+'</small><a class="fault-button" href="'+esc(model.path+'#'+code.anchor)+'">Model tablosunda göster →</a>';
  }
  brandOptions();
  el('faultDevice').addEventListener('change',()=>brandOptions());el('faultBrand').addEventListener('change',()=>modelOptions());el('faultModel').addEventListener('change',()=>{el('faultScope').checked=false;scope();});el('faultScope').addEventListener('change',()=>el('faultAnswer').textContent='');el('faultFind').addEventListener('click',show);
  el('faultCode').addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();show();}});
  const params=new URLSearchParams(location.hash.slice(1));if(['kombi','klima'].includes(params.get('cihaz')))el('faultDevice').value=params.get('cihaz');brandOptions(params.get('marka')||'');modelOptions(params.get('model_id')||'');if(params.has('kod'))el('faultCode').value=params.get('kod');
});
