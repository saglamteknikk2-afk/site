'use strict';
document.addEventListener('DOMContentLoaded',()=>{
  const box=document.getElementById('servisSecimi'),data=window.ST_SERVICE_DATA;
  if(!box||!data?.devices||!window.STResolveQuery)return;
  const el=id=>document.getElementById(id),names=['svcDistrict','svcNeighborhood','svcBrand','svcService','svcSymptom','svcLocality','svcModel','svcDetail'];
  let matchedPath='',scopeCheck=false,revision=0;
  const kind=()=>data.devices[el('svcDevice').value]?el('svcDevice').value:'kombi';
  const current=()=>data.devices[kind()];
  function neighborhoods(selected=''){
    const options=[new Option(el('svcDistrict').value?'Mahalle seçin / bilmiyorum':'Önce ilçenizi seçin','')];
    for(const r of data.neighborhoods.filter(r=>r.district===el('svcDistrict').value))options.push(new Option(r.name,r.name));
    el('svcNeighborhood').replaceChildren(...options);el('svcNeighborhood').value=options.some(o=>o.value===selected)?selected:'';
  }
  function deviceOptions(device,brand='',service='',symptom=''){
    const selected=data.devices[device]?device:'kombi';el('svcDevice').value=selected;
    const item=current();
    el('svcBrand').replaceChildren(new Option('Marka seçin / bilmiyorum',''),...item.brands.map(b=>new Option(b,b)));
    el('svcService').replaceChildren(...item.services.map(s=>new Option(s.name,s.path)));
    el('svcSymptom').replaceChildren(new Option('Belirti seçin / aşağıya yazın',''),...item.symptoms.map(s=>new Option(s.name,s.name)));
    el('svcBrand').value=item.brands.includes(brand)?brand:'';
    el('svcService').value=item.services.some(s=>s.path===service)?service:item.services[0].path;
    el('svcSymptom').value=item.symptoms.some(s=>s.name===symptom)?symptom:'';
    el('svcBrandLabel').textContent=item.label+' markası';
    el('svcCombiTab').setAttribute('aria-pressed',String(selected==='kombi'));
    el('svcClimateTab').setAttribute('aria-pressed',String(selected==='klima'));
    el('svcQuery').placeholder=selected==='klima'?'Örn. Sefaköy Daikin klima soğutmuyor':'Örn. Sefaköy Baymak kombi su akıtıyor';
  }
  function selection(){return {device:kind(),label:current().label,district:el('svcDistrict').value,neighborhood:el('svcNeighborhood').value,brand:el('svcBrand').value,service:el('svcService').selectedOptions[0]?.textContent||current().services[0].name,symptom:el('svcSymptom').value,locality:el('svcLocality').value.trim(),model:el('svcModel').value.trim(),detail:el('svcDetail').value.trim()}}
  function message(s){return ['Merhaba Sağlam Teknik, servis talebi oluşturmak istiyorum.','Cihaz: '+s.label,s.district&&'İlçe: '+s.district,s.neighborhood&&'Mahalle: '+s.neighborhood,s.locality&&'Semt / yakın konum: '+s.locality,s.brand&&s.label+' markası: '+s.brand,'İşlem: '+s.service,s.symptom&&'Belirti: '+s.symptom,s.model&&'Model / hata kodu: '+s.model,s.detail&&'Açıklama: '+s.detail].filter(Boolean).join('\n')}
  function update(show=false){
    const s=selection(),location=[s.neighborhood||s.locality,s.district].filter(Boolean).join(' / ');
    el('svcResultTitle').textContent=[location,s.brand,s.service].filter(Boolean).join(' · ');
    const parsed=window.STResolveQuery(data,[s.label,s.brand,s.model,s.symptom,s.district,s.neighborhood,s.locality].filter(Boolean).join(' '),s.device);
    el('svcResultDescription').textContent=parsed.error_code?'Bildirdiğiniz kod: '+parsed.error_code+'. Kodun anlamı tam modelin üretici kılavuzuyla doğrulanmalıdır; bu seçim kesin arıza teşhisi değildir.':s.symptom?'Bildirdiğiniz belirti: '+s.symptom+'. Model ve çalışma koşullarına göre servis planlamasını görüşelim.':'Marka, model ve varsa arıza belirtinizle randevu ve işlem kapsamını görüşelim.';
    el('svcWhatsApp').href='https://wa.me/905346225515?text='+encodeURIComponent(message(s));
    const symptom=current().symptoms.find(x=>x.name===s.symptom),candidate=parsed.error_guide_path||symptom?.path||matchedPath||(el('svcService').value!==current().services[0].path?el('svcService').value:parsed.path)||el('svcService').value;
    const allowed=current().services.concat(current().symptoms).some(x=>x.path===candidate)||(window.ST_ORGANIC_CATALOG?.published_routes||[]).includes(candidate.split('#')[0])||candidate==='hizmetler.html';
    el('svcGuide').href=allowed?candidate:current().services[0].path;
    el('svcGuide').textContent=parsed.error_guide_path?'Hata kodunu model bilgisiyle değerlendirin':symptom?'Arızayla ilgili rehberi incele':'İlgili servis bilgisini incele';
    el('svcScopeNotice').hidden=!scopeCheck;
    if(show||box.dataset.compact!=='true')el('svcResultCard').hidden=false;
  }
  function apply(a,replace=false){
    const inferred=window.STResolveQuery(data,a.query||'',kind()),selected=data.devices[a.device]?a.device:inferred.device;
    deviceOptions(selected,a.brand||(replace?'':el('svcBrand').value),a.service_path||a.path||'',a.symptom||inferred.symptom||'');
    if(data.districts.includes(a.district))el('svcDistrict').value=a.district;else if(replace)el('svcDistrict').value='';
    neighborhoods(a.neighborhood||'');
    if(a.locality)el('svcLocality').value=a.locality.slice(0,60);else if(replace)el('svcLocality').value='';
    if(replace){el('svcModel').value=[a.model,a.error_code].filter(Boolean).join(' · ');el('svcDetail').value=(a.query||'').slice(0,800)}
    matchedPath=a.path||'';scopeCheck=!!a.scope_check;update(replace);
  }
  function fragment(){
    const p=new URLSearchParams(location.hash.slice(1)),s=selection(),device=p.get('cihaz')||(p.get('islem')?.startsWith('/klima-')?'klima':s.device);
    if(!['cihaz','ilce','mahalle','marka','semt','islem','belirti','arama'].some(k=>p.has(k))){update();return}
    revision++;
    apply({device,district:p.get('ilce')||s.district,brand:p.get('marka')||s.brand,neighborhood:p.get('mahalle')||s.neighborhood,locality:p.get('semt')||s.locality,path:p.get('islem')||'',symptom:p.get('belirti')||'',query:p.get('arama')||''});
    if(p.has('arama')){const q=p.get('arama');el('svcQuery').value=q;apply(window.STResolveQuery(data,q,device),true)}
    if(location.hash){update(true);box.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'})}
  }
  deviceOptions(box.dataset.defaultDevice||'kombi');
  el('svcDistrict').value=data.districts.includes(box.dataset.defaultDistrict)?box.dataset.defaultDistrict:'';neighborhoods();
  window.addEventListener('hashchange',fragment);fragment();
  function switchDevice(device){revision++;const brand=el('svcBrand').value;deviceOptions(device,brand);matchedPath='';scopeCheck=false;el('svcModel').value='';el('svcDetail').value='';el('svcQuery').value='';el('svcSearchStatus').textContent='';update(true)}
  el('svcCombiTab').addEventListener('click',()=>switchDevice('kombi'));
  el('svcClimateTab').addEventListener('click',()=>switchDevice('klima'));
  for(const id of names)el(id).addEventListener(['svcDetail','svcModel','svcLocality'].includes(id)?'input':'change',()=>{revision++;if(id==='svcDistrict')neighborhoods();matchedPath='';scopeCheck=false;update(true)});
  el('svcSearchForm').addEventListener('submit',e=>{
    e.preventDefault();const q=el('svcQuery').value.trim();if(q.length<3)return;
    revision++;
    const result=window.STResolveQuery(data,q,kind());
    apply(result,true);
    el('svcSearchStatus').textContent=result.ambiguous_neighborhood?'Aynı adlı birden fazla mahalle var. İlçenizi seçip konumu tamamlayın.':result.error_code?'Kod '+result.error_code+' olarak eşleştirildi. Tam modeli kontrol edin; E1 ve E01 gibi farklı kodlar birleştirilmez.':result.found?'Bilgilerinizi cihazınızda eşleştirdik. Bölge, marka ve belirtiyi kontrol edip ilgili rehbere geçebilirsiniz.':'Eşleşen bir rehber bulunamadı. İlçe, marka ve belirtinizi seçimlerle tamamlayabilirsiniz.';
  });
  el('svcRecord').addEventListener('click',()=>{el('svcTicketForm').hidden=false;el('svcName').focus()});
  el('svcTicketForm').addEventListener('submit',async e=>{
    e.preventDefault();const form=e.currentTarget,s=selection();
    const district=[s.district,s.neighborhood,s.locality].filter(Boolean).join(' / '),issue=[s.service,s.brand&&'Marka: '+s.brand,s.symptom,s.model&&'Model / kod: '+s.model,s.detail].filter(Boolean).join(' · ');
    if(!district){el('svcOptions').open=true;el('svcTicketStatus').textContent='İlçe, mahalle veya semt bilginizi belirtin.';return}
    if(district.length>120){el('svcTicketStatus').textContent='Konum açıklamasını biraz kısaltın; ilçe ve mahalle bilgisi yeterlidir.';return}
    const payload={name:el('svcName').value.trim(),phone:el('svcPhone').value.trim(),district,device:s.label,issue,website:el('svcWebsite').value};
    el('svcTicketButton').disabled=true;el('svcTicketStatus').textContent='Talebiniz kaydediliyor…';
    try{await stApi('ticket',payload,stRequestKey(form,payload));el('svcTicketStatus').textContent='Talebiniz kaydedildi. Hızlı dönüş için 0534 622 5515 numarasını arayabilirsiniz.';form.dataset.requestBody='';form.dataset.requestKey=''}
    catch(e){el('svcTicketStatus').textContent=e.message||'Talep gönderilemedi; tekrar deneyin.'}
    finally{el('svcTicketButton').disabled=false}
  });
});
